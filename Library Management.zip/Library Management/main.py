from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import Base, Item  # Correct model reference

# Initialize Database
Base.metadata.create_all(bind=engine)

# Initialize FastAPI App
app = FastAPI()

# Mount static files (CSS)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Jinja2 Templates
templates = Jinja2Templates(directory="templates")

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 🚀 Home Page - List Books
@app.get("/")
def home(request: Request, db: Session = Depends(get_db)):
    books = db.query(Item).all()
    return templates.TemplateResponse("index.html", {"request": request, "books": books})

# ➕ Add Book Page
@app.get("/add")
def add_page(request: Request):
    return templates.TemplateResponse("add.html", {"request": request})

# 📜 List Books Page
@app.get("/list")
def list_books(request: Request, db: Session = Depends(get_db)):
    books = db.query(Item).all()
    return templates.TemplateResponse("list.html", {"request": request, "books": books})


# ➕ Add Book - POST
@app.post("/add")
def add_item(
    Author: str = Form(...),
    Genre: str = Form(...),
    Price: int = Form(...),
    Publication_year: int = Form(...),
    db: Session = Depends(get_db),
):
    new_book = Item(Author=Author, Genre=Genre, Price=Price, Publication_year=Publication_year)
    db.add(new_book)
    db.commit()
    return RedirectResponse(url="/", status_code=303)

# ✏️ Edit Book Page
@app.get("/edit/{book_id}")
def edit_page(book_id: int, request: Request, db: Session = Depends(get_db)):
    book = db.query(Item).filter(Item.book_id == book_id).first()  # ✅ Fixed primary key reference
    if not book:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse("edit.html", {"request": request, "book": book})

# ✏️ Edit Book - POST
@app.post("/edit/{book_id}")
def edit_item(
    book_id: int,
    Author: str = Form(...),
    Genre: str = Form(...),
    Price: int = Form(...),
    Publication_year: int = Form(...),
    db: Session = Depends(get_db),
):
    book = db.query(Item).filter(Item.book_id == book_id).first()  # ✅ Fixed primary key reference
    if not book:
        return RedirectResponse(url="/", status_code=303)

    book.Author = Author
    book.Genre = Genre
    book.Price = Price
    book.Publication_year = Publication_year
    db.commit()
    return RedirectResponse(url="/", status_code=303)

# 🗑 Delete Book
@app.get("/delete/{book_id}")
def delete_item(book_id: int, db: Session = Depends(get_db)):
    book = db.query(Item).filter(Item.book_id == book_id).first()  # ✅ Fixed primary key reference
    if not book:
        return RedirectResponse(url="/", status_code=303)

    db.delete(book)
    db.commit()
    return RedirectResponse(url="/list", status_code=303)
