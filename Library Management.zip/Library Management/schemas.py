from pydantic import BaseModel
from sqlalchemy import Integer


class ItemCreate(BaseModel):
    Author: str
    Genre: str
    Price:int
    Publication_year: int


class ItemResponse(ItemCreate):
    item_id: int

    class Config:
        orm_mode = True
