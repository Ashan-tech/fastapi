
from fastapi import FastAPI, Request, Form, Depends
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from .models import Base, Student, Course
from .database import engine, get_db

Base.metadata.create_all(bind=engine)
app = FastAPI()
templates = Jinja2Templates(directory="templates")

@app.get("/")
def index(request: Request, db: Session = Depends(get_db)):
    students = db.query(Student).all()
    courses = db.query(Course).all()
    return templates.TemplateResponse("index.html", {"request": request, "students": students, "courses": courses})

@app.post("/add_student")
def add_student(request: Request, name: str = Form(...), db: Session = Depends(get_db)):
    student = Student(name=name)
    db.add(student)
    db.commit()
    return RedirectResponse("/", status_code=303)

@app.post("/add_course")
def add_course(request: Request, name: str = Form(...), db: Session = Depends(get_db)):
    course = Course(name=name)
    db.add(course)
    db.commit()
    return RedirectResponse("/", status_code=303)

@app.post("/enroll")
def enroll_student(request: Request, student_id: int = Form(...), course_id: int = Form(...), db: Session = Depends(get_db)):
    student = db.query(Student).get(student_id)
    course = db.query(Course).get(course_id)
    student.courses.append(course)
    db.commit()
    return RedirectResponse("/", status_code=303)
